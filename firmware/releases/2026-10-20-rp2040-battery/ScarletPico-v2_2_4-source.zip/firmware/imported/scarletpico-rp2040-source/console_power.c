#include "console.h"
#include "console_power.h"
#include "battery_model.h"
#include "hardware/adc.h"
#include <stdatomic.h>
#include <stdio.h>
#include <string.h>

/* Conditioned, isolated active-low charger signals, NOT raw 5 V LED nodes. */
#define POWER_ADC_PIN 29
#define POWER_CHARGING_PIN 18
#define POWER_COMPLETE_PIN 19
#define POWER_ENABLED (1u<<20)
#define POWER_VALID (1u<<21)
#define POWER_LOW (1u<<22)
static atomic_uint snapshot;
static bool enabled;
static battery_model_t model;
static uint64_t next_poll,next_adc;
static unsigned candidate,stable,candidate_count;
static const char *charge_names[]={"IDLE/UNKNOWN","CHARGING","CHARGE DONE","CHECK SIGNALS"};

static void enable(bool on) {
  enabled=on;memset(&model,0,sizeof model);
  candidate=stable=BAT_IDLE;candidate_count=0;next_poll=next_adc=0;
  if(on) {
    adc_init();adc_gpio_init(POWER_ADC_PIN);adc_select_input(3);
    gpio_init(POWER_CHARGING_PIN);gpio_set_dir(POWER_CHARGING_PIN,GPIO_IN);gpio_pull_up(POWER_CHARGING_PIN);
    gpio_init(POWER_COMPLETE_PIN);gpio_set_dir(POWER_COMPLETE_PIN,GPIO_IN);gpio_pull_up(POWER_COMPLETE_PIN);
  } else {
    /* High impedance, not driven low: no output contention with future wiring. */
    const unsigned pins[]={POWER_ADC_PIN,POWER_CHARGING_PIN,POWER_COMPLETE_PIN};
    for(unsigned i=0;i<3;i++){gpio_init(pins[i]);gpio_set_dir(pins[i],GPIO_IN);gpio_disable_pulls(pins[i]);}
  }
  atomic_store(&snapshot,on?POWER_ENABLED:0);
}
void console_power_init(const uint8_t *p) {
  /* Append-only extension: the original 16-byte UI record remains compatible. */
  bool ok=p&&memcmp(p+16,"BAT1",4)==0&&p[20]<=1&&p[21]==(uint8_t)~p[20];
  enable(ok&&p[20]==1);
}
void console_power_record(uint8_t *p) {
  memcpy(p+16,"BAT1",4);p[20]=enabled;p[21]=(uint8_t)~p[20];
}
/* Hardware-only boundaries kept callable for compiled ARM regression tests. */
__attribute__((noinline)) unsigned console_power_read_sample(void) {
  adc_select_input(3);(void)adc_read();
  unsigned sum=0;for(unsigned i=0;i<16;i++)sum+=adc_read();
  return (sum+8)/16;
}
__attribute__((noinline)) unsigned console_power_charge_pins(void) {
  return (!gpio_get(POWER_CHARGING_PIN))|((!gpio_get(POWER_COMPLETE_PIN))<<1);
}
void console_power_poll(void) {
  if(!enabled)return;
  uint64_t now=time_us_64();if(now<next_poll)return;next_poll=now+100000;
  unsigned pins=console_power_charge_pins();
  unsigned state=battery_charge_state(pins&1,pins&2);
  if(state!=candidate){candidate=state;candidate_count=1;}
  else if(candidate_count<4)candidate_count++;
  if(candidate_count==4)stable=candidate;
  if(now>=next_adc) {
    next_adc=now+1000000;
    battery_model_sample(&model,battery_adc_mv(console_power_read_sample()));
  }
  unsigned packed=POWER_ENABLED|(stable<<16)|(model.bars<<13)|model.millivolts;
  if(model.valid)packed|=POWER_VALID;
  if(model.low)packed|=POWER_LOW;
  atomic_store(&snapshot,packed);
}
static void voltage(unsigned p,char out[24]) {
  unsigned mv=p&8191;
  if(!(p&POWER_ENABLED))snprintf(out,24,"MONITOR OFF");
  else if(!(p&POWER_VALID))snprintf(out,24,"SENSOR CHECK");
  else snprintf(out,24,"%u.%02u V",mv/1000,(mv%1000)/10);
}
void console_power_header(void) {
  unsigned p=atomic_load(&snapshot);char text[24];voltage(p,text);
  uint16_t color=p&POWER_LOW?UI_ACCENT:UI_TEAL;
  ui_rect(302,4,178,39,UI_SURFACE);
  /* Five battery segments; no unsupported precise percentage claim. */
  ui_rect(304,10,33,17,UI_MUTED);ui_rect(306,12,29,13,UI_SURFACE);ui_rect(337,15,3,7,UI_MUTED);
  if(p&POWER_VALID)for(unsigned i=0;i<((p>>13)&7);i++)ui_rect(308+i*5,14,3,9,color);
  ui_text(347,9,text,color,UI_SURFACE,1,21);
  const char *status=!(p&POWER_ENABLED)?"WIRING REQUIRED":charge_names[(p>>16)&3];
  if((p&POWER_LOW)&&((p>>16)&3)!=BAT_CHARGING)status="LOW - SAVE GAME";
  ui_text(347,25,status,UI_MUTED,UI_SURFACE,1,21);
}
void console_power_ui_tick(void) {
  unsigned old=atomic_load(&snapshot);console_power_poll();
  if(old!=atomic_load(&snapshot))console_power_header();
}
void console_power_game(void) {
  unsigned p=atomic_load(&snapshot);if(!(p&POWER_ENABLED))return;
  char text[24];voltage(p,text);
  /* x2 native game occupies x=80..399,y=16..303. Left rail is core-1-owned. */
  ui_rect(0,2,78,31,0);ui_text(2,3,text,p&POWER_LOW?UI_ACCENT:UI_TEXT,0,1,12);
  const char *status=charge_names[(p>>16)&3];
  if((p&POWER_LOW)&&((p>>16)&3)!=BAT_CHARGING)status="LOW BATTERY";
  ui_text(2,16,status,UI_TEAL,0,1,12);
  if(p&POWER_VALID)for(unsigned i=0;i<5;i++)
    ui_rect(2+i*12,27,9,3,i<((p>>13)&7)?UI_TEAL:UI_TRACK);
}
static void page_rows(void) {
  unsigned p=atomic_load(&snapshot);char text[24];
  voltage(p,text);
  feature_row(0,9,"BATTERY",text);
  if(p&POWER_VALID)snprintf(text,sizeof text,"%u / 5 BARS",(p>>13)&7);else strcpy(text,"UNKNOWN");
  feature_row(1,9,"VOLTAGE LEVEL",text);
  feature_row(2,9,"TP4056",enabled?charge_names[(p>>16)&3]:"NOT ENABLED");
  feature_row(3,9,"MONITOR",enabled?"ON":"OFF");
  feature_row(4,9,"INPUTS","29 / 18 / 19");
}
static void page_draw(void) {
  feature_page("BATTERY / CHARGER");page_rows();
  feature_footer("A: ENABLE/DISABLE   B: BACK","LEVEL IS APPROXIMATE; IDLE DOES NOT PROVE USB IS ABSENT");
}
void console_power_page(void) {
  console_power_poll();page_draw();feature_release();uint8_t last=0;
  for(;;) {
    unsigned old=atomic_load(&snapshot);console_power_poll();
    if(old!=atomic_load(&snapshot)){console_power_header();page_rows();}
    uint8_t k=feature_keys(),edge=k&~last;last=k;
    if(edge&UI_B)break;
    if(edge&UI_A) {
      if(!enabled) {
        feature_page("HARDWARE CONFIRMATION");
        ui_text(20,104,"ONLY AFTER THE SENSE CIRCUIT IS INSTALLED",UI_TEXT,UI_BG,1,73);
        ui_text(20,126,"GP29: DIVIDER / GP18,19: ISOLATED STATUS",UI_TEXT,UI_BG,1,73);
        ui_text(20,148,"NEVER CONNECT BATTERY OR 5V LED NODES DIRECTLY",UI_ACCENT,UI_BG,1,73);
        feature_footer("A: CONFIRM WIRED HARDWARE","B: CANCEL");feature_release();
        uint8_t confirm=0;while(!(confirm&(UI_A|UI_B))){confirm=feature_keys();sleep_ms(5);}
        if(confirm&UI_A)enable(true);
      } else enable(false);
      console_power_poll();page_draw();feature_release();last=0;
    }
    sleep_ms(5);
  }
  feature_release();
}
