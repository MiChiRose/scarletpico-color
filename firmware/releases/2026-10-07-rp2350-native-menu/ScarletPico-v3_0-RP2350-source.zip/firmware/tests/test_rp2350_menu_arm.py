"""Execute the compiled Cortex-M33 menu, pause and snapshot bindings.

Only peripheral/SD I/O is stubbed. This is not a physical LCD/FPS test.
"""
from pathlib import Path
import struct
from elftools.elf.elffile import ELFFile
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_THUMB, UC_MODE_MCLASS, UC_HOOK_CODE, UC_HOOK_MEM_WRITE
from unicorn.arm_const import *

ROOT=Path(__file__).resolve().parents[1]
elf=ELFFile((ROOT/'build-rp2350-source/scarlet2350.elf').open('rb'))
uc=Uc(UC_ARCH_ARM,UC_MODE_THUMB|UC_MODE_MCLASS)
# macOS must allow Unicorn's local JIT mappings; a restricted execution
# sandbox may trap on mem_map. Tests never connect to USB hardware.
uc.ctl_set_cpu_model(UC_CPU_ARM_CORTEX_M33)
uc.mem_map(0x10000000,0x400000);uc.mem_map(0x20000000,0x84000)
uc.mem_map(0x40000000,0x1000000);uc.mem_map(0x50000000,0x1000000)
uc.mem_map(0xd0000000,0x10000);uc.mem_map(0xe0000000,0x100000)
for section in elf.iter_sections():
    a=section['sh_addr'];n=section['sh_size']
    if n and section['sh_flags']&2 and section['sh_type']!='SHT_NOBITS':
        uc.mem_write(a,section.data())
sym={s.name:s['st_value'] for s in elf.get_section_by_name('.symtab').iter_symbols() if s.name}
R=[UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3]
END=0x10000300
hooks={};ticks=0;sequence=[];rects=[];windows=[];brightness=[];flash_ops=[];events=[]
def read32(a):return struct.unpack('<I',uc.mem_read(a,4))[0]
def write32(a,v):uc.mem_write(a,struct.pack('<I',v&0xffffffff))
def alias_write(u,access,a,n,v,data):
    alias=(a>>12)&3
    if not alias:return
    target=a-alias*4096;old=read32(target)
    write32(target,old^v if alias==1 else old|v if alias==2 else old&~v)
uc.hook_add(UC_HOOK_MEM_WRITE,alias_write,begin=0x40000000,end=0x40ffffff)
uc.hook_add(UC_HOOK_MEM_WRITE,alias_write,begin=0x50000000,end=0x50ffffff)
def ret(v=0):
    uc.reg_write(R[0],v);uc.reg_write(UC_ARM_REG_PC,uc.reg_read(UC_ARM_REG_LR))
def stub(name,fn):hooks[sym[name]&~1]=fn
def hook(u,a,n,d):
    if a in hooks:hooks[a](*(u.reg_read(r) for r in R))
uc.hook_add(UC_HOOK_CODE,hook)
def call(name,*args):
    uc.reg_write(UC_ARM_REG_SP,0x20081000);uc.reg_write(UC_ARM_REG_LR,END|1)
    for r,v in zip(R,args):uc.reg_write(r,v)
    uc.emu_start(sym[name]|1,END,count=20000000)
    assert uc.reg_read(UC_ARM_REG_PC)==END,(name,hex(uc.reg_read(UC_ARM_REG_PC)))
    return uc.reg_read(R[0])
def key(*_):
    k=next((k for lo,hi,k in sequence if lo<=ticks<hi),0);ret(k)
def sleep(ms,*_):
    global ticks
    ticks+=ms*1000;ret()
def time(*_):uc.reg_write(R[1],ticks>>32);ret(ticks&0xffffffff)
def rect(x,y,w,h):
    assert w and h and x+w<=480 and y+h<=320,(x,y,w,h)
    rects.append((x,y,w,h));ret()
def begin(x,y,w,h):
    assert w and h and x+w<=480 and y+h<=320
    windows.append((x,y,w,h));ret()
stub('feature_keys',key);stub('sleep_ms',sleep);stub('time_us_64',time)
stub('display_rect',rect);stub('display_ui_begin',begin)
stub('display_ui_row',lambda p,n,*_:(bytes(uc.mem_read(p,n)),ret()))
stub('display_ui_end',lambda *_:ret())
stub('ui_apply_brightness',lambda v,*_:(brightness.append(v),ret()))
stub('display_width',lambda *_:ret(320));stub('display_height',lambda *_:ret(288))
labels=0x20070000
for i in range(192):uc.mem_write(labels+i*40,f'Game {i:03d}.gb'.encode()+b'\0')
stub('native_game_count',lambda *_:ret(192))
stub('native_game_label',lambda i,*_:ret(labels+i*40))
stub('native_game_color',lambda i,*_:ret(i==1))
stub('native_game_folder',lambda i,*_:ret(i==0))
stub('original_audio_stop',lambda *_:(events.append('audio_stop'),ret()))
stub('original_audio_start',lambda *_:(events.append('audio_start'),ret(1)))
stub('native_video_stop',lambda *_:(events.append('video_stop'),ret()))
stub('native_video_start',lambda *_:(events.append('video_start'),ret()))
def erase(off,n,*_):
    assert off==0x7f000 and n==4096
    flash_ops.append('erase');uc.mem_write(0x10000000+off,b'\xff'*n);ret()
def program(off,p,n,*_):
    assert off==0x7f000 and n==256
    flash_ops.append('program');uc.mem_write(0x10000000+off,bytes(uc.mem_read(p,n)));ret()
stub('flash_range_erase',erase);stub('flash_range_program',program)
uc.mem_write(0x1007f000,b'\xff'*4096)
call('features_ui_init',0)
assert bytes(uc.mem_read(sym['ui_volume'],1))==b'\x32' and brightness[-1]==100

# Actual menu loop: select the next game. Full paint once; key navigation must
# stay in the list/metadata strips, never clear the entire display again.
ticks=0;sequence=[(60000,120000,4),(180000,240000,1)]
rects.clear();windows.clear();assert call('console_menu',0)==1
assert sum(r==(0,0,480,320) for r in rects)==1
call('ui_menu_draw',0);before=len(rects);call('ui_menu_draw',0);assert len(rects)==before
# All 192 entries accessible, not silently clamped to the historical 32.
ticks=0;sequence=[(60000,120000,1)];assert call('console_menu',191)==191
print('PASS ARM menu: original UI, idle is unchanged, no full redraw on selection, 192 entries')

# Settings from a real menu: Right, volume up, brightness down, B, then launch.
ticks=0;sequence=[(60000,120000,16),(180000,240000,16),(300000,360000,128),
 (420000,480000,32),(540000,600000,2),(660000,720000,1)]
assert call('console_menu',0)==0
assert uc.mem_read(sym['ui_volume'],1)==b'\x3c' and uc.mem_read(sym['ui_settings']+2,1)==b'\x5a'
# The same-TU brightness call is inlined by GCC: verify the actual PWM CC,
# not the separately stubbed call ui_init uses during reboot.
assert read32(0x400a8070)&65535==900
assert flash_ops==['erase','program']
call('features_ui_init',0x1007f000)
assert uc.mem_read(sym['ui_volume'],1)==b'\x3c' and brightness[-1]==90
print('PASS ARM settings: volume/brightness, safe reserved flash sector, reboot persistence')

# Real chord filtering, 1.5 seconds, consume release, individual keys unchanged.
call('console_input_reset');ticks=0;sequence=[]
assert call('features_buttons',12)==0;ticks=1499999
assert call('features_buttons',12)==0 and uc.mem_read(sym['pause_pending'],1)==b'\0'
ticks=1500000;assert call('features_buttons',12)==0
assert uc.mem_read(sym['pause_pending'],1)==b'\1'
events.clear();sequence=[(ticks+60000,ticks+120000,2)]
assert call('features_frame',255,1)==1
assert events==['audio_stop','video_stop','video_start','audio_start'],events
assert uc.mem_read(sym['pause_pending'],1)==b'\0'
assert call('features_buttons',8)==8 and call('features_buttons',4)==4
print('PASS ARM pause: chord withheld from game, halt/resume order, buttons consumed')

# Exit is confirmed explicitly. The worker is not restarted just to exit.
call('console_input_reset');uc.mem_write(sym['pause_pending'],b'\1')
ticks=0;sequence=[(60000,120000,64),(180000,240000,1),(300000,360000,1)]
events.clear();assert call('features_frame',255,1)==1
assert uc.mem_read(sym['exit_requested'],1)==b'\1'
assert events==['audio_stop','video_stop'],events
uc.mem_write(sym['exit_requested'],b'\0')
print('PASS ARM exit: explicit confirmation, stopped worker, no automatic launch')

# The actual native state helpers strip and reinstall live function pointers.
size=call('native_core_size');assert size==0xc320
gb=sym['gb'];scratch=0x20070000
uc.mem_write(gb,b'\x11'*size);call('native_core_copy',scratch)
assert bytes(uc.mem_read(scratch,28))==b'\0'*28
assert uc.mem_read(scratch+28,1)==b'\x11'
call('native_core_restore',scratch)
assert read32(gb)==sym['rom_read']|1 and read32(gb+12)==sym['emulation_error']|1
assert read32(gb+16)==0 and read32(gb+20)==0 and read32(gb+24)==0
assert uc.mem_read(gb+0xc319,1)==b'\xff'
print('PASS ARM native snapshot ABI: actual structure size, strip/restore callbacks, joypad release')

# Actual producer and APU, while physical DMA clocks are deliberately stubbed.
uc.mem_write(sym['active'],b'\1');uc.mem_write(sym['playing'],b'\1')
queue=sym['original_audio_queue'];pcm=0x20070000
uc.mem_write(pcm,struct.pack('<hhhh',1000,3000,-1000,-3000))
for vol in (0,50,100):
    uc.mem_write(sym['ui_volume'],bytes([vol]));write32(queue+2048,0);write32(queue+2052,0)
    call('original_audio_submit',pcm,2)
    v=20*vol;nv=(-v)&65535
    assert struct.unpack('<II',uc.mem_read(queue,8))==(v|(v<<16),nv|(nv<<16))
call('console_apu_init');write32(queue+2048,0);write32(queue+2052,0)
samples=0
for i in range(120):
    write32(queue+2048,0);write32(queue+2052,0);call('console_audio_frame')
    n=read32(queue+2048);assert n in (267,268);samples+=n
assert samples==(120*16000*70224>>22)
print('PASS ARM audio: mono preserves both channels at 0/50/100%, exact 59.7275 Hz PCM sample scheduling')

# Run the actual I2S startup/configuration with SDK allocation functions mocked.
# Channel 0 (LCD), 1/2 (SD) are reserved; this code must claim 3/4 and IRQ 2.
hooks.pop(sym['original_audio_start']&~1)
claimed=[3,4];configs=[];irq_handlers=[];pins=[]
stub('dma_claim_unused_channel',lambda required,*_:ret(claimed.pop(0)))
stub('pio_claim_unused_sm',lambda *_:ret(0))
stub('pio_can_add_program',lambda *_:ret(1));stub('pio_add_program',lambda *_:ret(24))
stub('gpio_set_function',lambda pin,fn,*_:(pins.append(pin),ret()))
stub('pio_sm_set_consecutive_pindirs',lambda p,sm,pin,count:ret())
stub('pio_sm_init',lambda p,sm,off,cfg:(configs.append((p,sm,off,bytes(uc.mem_read(cfg,16)))),ret()))
stub('irq_add_shared_handler',lambda irq,p,*_:(irq_handlers.append(irq),ret()))
stub('irq_set_enabled',lambda *_:ret());stub('clock_get_hz',lambda *_:ret(200000000))
uc.mem_write(sym['playing'],b'\0');uc.mem_write(sym['active'],b'\0')
write32(0x5000000c,0x13579);assert call('original_audio_start')==1
assert claimed==[] and pins==[11,12,13] and irq_handlers==[12]
assert configs[0][:3]==(0x50300000,0,24)
clkdiv,execctrl,shiftctrl,pinctrl=struct.unpack('<4I',configs[0][3])
assert clkdiv==50000<<8 and (pinctrl&31)==13 and (pinctrl>>10&31)==11
assert read32(0x50000424)&24==24
for i,ch in enumerate((3,4)):
    ctrl=read32(0x50000010+64*ch)
    assert ctrl&1 and (ctrl>>13&15)==(4 if i==0 else 3) and (ctrl>>17&63)==8
    assert read32(0x50000004+64*ch)==0x50300010
uc.mem_write(sym['ui_volume'],b'\x32');uc.mem_write(pcm,struct.pack('<hh',1000,3000)*384)
call('original_audio_submit',pcm,384)
assert read32(queue+2048)==384 and read32(queue+2052)==256
assert read32(0x50000450)==8 and read32(0x50300000)&1
write32(0x5000042c,8);call('audio_irq')
assert read32(queue+2052)==384 and read32(0x50000008+3*64)==128
assert read32(0x5000000c)==0x13579
print('PASS ARM I2S: separate claimed DMA 3/4 + IRQ2, 16 kHz divider, 384-frame prefill, completed-half refill, LCD DMA untouched')
